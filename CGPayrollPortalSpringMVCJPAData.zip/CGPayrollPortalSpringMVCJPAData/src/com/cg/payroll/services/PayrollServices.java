package com.cg.payroll.services;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
public interface PayrollServices {
	
	
	
	int calculateNetSalary(int associateId)throws AssociateDetailsNotFoundException;
	double calculateGrossSalary(int associateId)throws AssociateDetailsNotFoundException;
	Associate getAssociateDetails(int associateId)throws AssociateDetailsNotFoundException;
	
	List<Associate> getAllAssociatesDetails();

	int acceptAssociateDetails(int id, String firstName, String lastName, String emailId, String department,
			String designation, String pancard, int yearlyInvestmentUnder8oC, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode);

	Associate acceptAssociateDetails(Associate associate);

	
	
	
	
	
}

