
  package com.cg.payroll.tests;

public class PayrollServicesTest {
  
	/*
	 * private static PayrollServices services;
	 * 
	 * @BeforeClass public static void setUpTestEnv() { services = new
	 * PayrollServicesImpl(); }
	 * 
	 * @Before public void setUpTestData() { Associate associate1 = new
	 * Associate(1001, 78000, "Tirtharaj", "Sur", "JEE", "Jn Cons",
	 * "APQ1256CDS","tirtharajsur@gmail.com", new Salary(35000, 1800, 1800), new
	 * BankDetails(12345, "CITI Bank", "CITI000051")); Associate associate2 = new
	 * Associate(1002, 75000, "Laltu", "Gopal", "JEE", "Jn Cons",
	 * "JWK1256BCS","laltukole@gmail.com", new Salary(25000, 1800, 1800), new
	 * BankDetails(12345, "HDFC", "HDFC00059"));
	 * 
	 * PayrollDBUtil.associates.put(associate1.getAssociateId(),associate1);
	 * PayrollDBUtil.associates.put(associate2.getAssociateId(),associate2);
	 * 
	 * PayrollDBUtil.ASSOCIATE_ID_COUNTER=1002; }
	 * 
	 * @Test(expected=AssociateDetailsNotFoundException.class) public void
	 * testGetAssociateDetailsForInvalidAssociates() throws
	 * AssociateDetailsNotFoundException { services.getAssociateDetails(12345);
	 * 
	 * }
	 * 
	 * @Test public void testGetAssociateDetailsForValidAssociates() throws
	 * AssociateDetailsNotFoundException { Associate expectedAssociate = new
	 * Associate(1002, 75000, "Laltu", "Gopal", "JEE", "Jn Cons",
	 * "JWK1256BCS","laltukole@gmail.com", new Salary(25000, 1800, 1800), new
	 * BankDetails(12345, "HDFC", "HDFC00059")); Associate actualAssociate =
	 * services.getAssociateDetails(1002);
	 * Assert.assertEquals(expectedAssociate,actualAssociate); }
	 * 
	 * @Test public void testAcceptAssociateDetailsForValidData() { int expectedId =
	 * 1003; int actualId = services.acceptAssociateDetails("ABC",
	 * "PQR","dsfkjb@gmail.com","JEE","shgfdaj","sfdhgasvfd", 18200,22000,
	 * 1800,1800,123456, "CITI Bank","HASGD001"); Assert.assertEquals(expectedId,
	 * actualId);
	 * 
	 * }
	 * 
	 * @Test(expected=AssociateDetailsNotFoundException.class) public void
	 * testCalculateNetSalaryForInvalidAssociateId() throws
	 * AssociateDetailsNotFoundException { services.calculateNetSalary(1434); }
	 * 
	 * @Test public void testCalculateNetSalaryForValidAssociateId() throws
	 * AssociateDetailsNotFoundException { double expectedNetSalary = 661800; double
	 * actualNetSalary = services.calculateNetSalary(1002);
	 * Assert.assertEquals(expectedNetSalary , actualNetSalary,0); }
	 * 
	 * @Test(expected=AssociateDetailsNotFoundException .class) public void
	 * testCalculateGrossSalaryForInvalidAssociate() throws
	 * AssociateDetailsNotFoundException { services.calculateGrossSalary(1434); }
	 * 
	 * @Test public void testCalculateGrossSalaryForValidAssociate() throws
	 * AssociateDetailsNotFoundException { double expectedGrossSalary =54850 ;
	 * double actualGrossSalary = services.calculateGrossSalary(1002);
	 * Assert.assertEquals(expectedGrossSalary , actualGrossSalary,0); }
	 * 
	 * 
	 * 
	 * @Test public void testGetAllAssociateDetails() { Associate associate1 = new
	 * Associate(1001, 78000, "Tirtharaj", "Sur", "JEE", "Jn Cons",
	 * "APQ1256CDS","tirtharajsur@gmail.com", new Salary(35000, 1800, 1800), new
	 * BankDetails(12345, "CITI Bank", "CITI000051")); Associate associate2 = new
	 * Associate(1002, 75000, "Laltu", "Gopal", "JEE", "Jn Cons",
	 * "JWK1256BCS","laltukole@gmail.com", new Salary(25000, 1800, 1800), new
	 * BankDetails(12345, "HDFC", "HDFC00059"));
	 * 
	 * ArrayList<Associate>expectedAssociateList = new ArrayList<>();
	 * expectedAssociateList.add(associate1); expectedAssociateList.add(associate2);
	 * 
	 * ArrayList<Associate>actualAssociateList = (ArrayList<Associate>)
	 * services.getAllAssociateDetails(); Assert.assertEquals(expectedAssociateList,
	 * expectedAssociateList); }
	 * 
	 * 
	 * 
	 * @After public void tearDownTestData() { PayrollDBUtil.associates.clear();
	 * PayrollDBUtil.ASSOCIATE_ID_COUNTER=1000; }
	 * 
	 * 
	 * @AfterClass public static void tearDownTestEnv() { services = null; }
	 */
	  
	  
  
  }
 