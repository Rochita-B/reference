package com.cg.banking.services;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public interface BankingServices {

	Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException;
	Account openAccount(Account account);

	HashMap<Integer, Account> getAllAccountDetails() throws BankingServicesDownException;

	Map<Integer,Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException;

	public Optional<Account> accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException;

	Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException;
	
	/*
	 * boolean fundTransfer(Account accountNoFrom, Account accountNoTo, float
	 * transferAmount, long pinNumber) throws InsufficientAmountException,
	 * AccountNotFoundException, InvalidPinNumberException,
	 * BankingServicesDownException, AccountBlockedException;
	 */

	

}
