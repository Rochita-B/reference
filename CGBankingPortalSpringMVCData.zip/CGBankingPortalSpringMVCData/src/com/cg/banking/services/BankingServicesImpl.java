package com.cg.banking.services;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;

@Component("bankingServices")
public class BankingServicesImpl implements BankingServices{
	@Autowired
	private AccountDAO accountDAO;

	private TransactionDAO transactionsDAO;
	private final static float minBal = 1000;

	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		if(initBalance<minBal)
			throw new InvalidAmountException();
		CrudRepository<Account, Integer> accountDAO = null;
		Account customer=accountDAO.save(new Account(accountType,initBalance));
		 transactionsDAO.save(new Transaction(initBalance,"Deposit",customer) ); 
		return customer;
	}

	@Override
	public Account openAccount(Account account) {
		return accountDAO.save(account);
	}
	/*
	 * @Override public float depositAmount(long account, float amount) throws
	 * AccountNotFoundException, BankingServicesDownException,
	 * AccountBlockedException { //Account customers = null; Optional<Account>
	 * customers = accountDAO.findById((int) account); if(customers==null) throw new
	 * AccountNotFoundException(); else
	 * if(customers.getAccountStatus().equalsIgnoreCase("Blocked")) throw new
	 * AccountBlockedException(); else
	 * customers.setAccountBalance(customers.getAccountBalance()+amount);
	 * transactionsDAO.save(customers,new Transaction(amount,"Deposit") ); return
	 * customers.getAccountBalance(); }
	 */
	/*
	 * @Override public float withdrawAmount(long accountNo, float amount, long
	 * pinNumber) throws InsufficientAmountException, AccountNotFoundException,
	 * InvalidPinNumberException, BankingServicesDownException,
	 * AccountBlockedException { Optional<Account> customers =
	 * accountDAO.findById((int) accountNo); if(customers==null) throw new
	 * AccountNotFoundException(); else
	 * if(customers.getAccountStatus().equalsIgnoreCase("Blocked")) throw new
	 * AccountBlockedException(); else if(customers.getPinNumber()!=pinNumber) throw
	 * new InvalidPinNumberException(); else if(customers.getAccountBalance()-amount
	 * <=minBal) throw new InsufficientAmountException(); else
	 * customers.setAccountBalance(customers.getAccountBalance()-amount);
	 * transactions.save(customers,new Transaction(amount,"Withdraw") ); return
	 * customers.getAccountBalance(); }
	 */

	
	/*
	 * @Override public boolean fundTransfer(Account accountNoFrom,Account
	 * accountNoTo, float transferAmount, long pinNumber) throws
	 * InsufficientAmountException, AccountNotFoundException,
	 * InvalidPinNumberException, BankingServicesDownException,
	 * AccountBlockedException { Account customerTo =
	 * getAccountDetails(accountNoTo); Optional<Account> customerFrom =
	 * getAccountDetails(accountNoFrom);
	 * 
	 * 
	 * if(customerFrom.getAccountBalance()-transferAmount <=minBal) throw new
	 * InsufficientAmountException(); else
	 * if(customerFrom.getPinNumber()!=pinNumber) throw new
	 * InvalidPinNumberException(); else {
	 * //withdrawAmount(customerFrom.getAccountNo(), transferAmount,
	 * customerFrom.getPinNumber());
	 * customerFrom.setAccountBalance(customerFrom.getAccountBalance()-
	 * transferAmount); transactionsDAO.save(customerFrom,new
	 * Transaction(transferAmount,"Withdraw") );
	 * depositAmount(customerTo.getAccountNo(), transferAmount); } return true; }
	 */

	@Override
	public HashMap<Integer,Account> getAllAccountDetails() throws BankingServicesDownException {
		HashMap<Integer,Account> customers = (HashMap<Integer, Account>) accountDAO.findAll();		
		return (HashMap<Integer, Account>) customers;
	}
	@Override
	public Map<Integer,Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {	
		return (Map<Integer, Transaction>) transactionsDAO.findAll();
	}
	@Override
	public Optional<Account> accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		return accountDAO.findById((long) accountNo);

	}

	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {

		return accountDAO.findById((long) accountNo)
				.orElseThrow(()-> new AccountNotFoundException("Account is not found for this account number"+accountNo));
	}


}


